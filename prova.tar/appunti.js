var getPixels = require("get-pixels")

let data

getPixels("lena.png", function(err, pixels) {
  if(err) {
    console.log("Bad image path")
    return
  }
  data = pixels
})

// capire come ottenere le "colonne"

console.log(data.shape)

data.get(400,300,1)

//////////////////////////////////////////


var zeros = require("zeros")
var savePixels = require("save-pixels")
 
//Create an image
var x = zeros([32, 32])
x.set(16, 16, 255)
 
//Save to a file
savePixels(x, "png").pipe(process.stdout)

